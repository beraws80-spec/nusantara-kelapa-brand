'use client';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import menuData from './data/menu';

export default function Home() {
  return (
    <main style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
      <header style={{padding: '28px 24px', display:'flex', justifyContent:'space-between', alignItems:'center', background:'#fff'}}>
        <div style={{fontWeight:800, color:'#064e3b'}}>NUSANTARA KELAPA</div>
        <nav style={{display:'flex', gap:20}}>
          <Link href='/'>Home</Link>
          <Link href='/menu'>Menu</Link>
          <Link href='/franchise'>Franchise</Link>
          <Link href='/about'>Tentang</Link>
          <Link href='/gallery'>Galeri</Link>
          <Link href='/branches'>Cabang</Link>
          <Link href='/contact'>Kontak</Link>
        </nav>
      </header>

      <section style={{padding:60, textAlign:'center', background: 'linear-gradient(180deg,#f0fff4,#ffffff)'}}>
        <motion.h1 initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{duration:0.6}} style={{fontSize:48, color:'#064e3b'}}>Fresh • Tropical • Premium Coconut Beverage</motion.h1>
        <p style={{maxWidth:800, margin:'16px auto', color:'#2d3748'}}>10 tahun menghadirkan minuman kelapa terbaik - ready for national expansion and franchise partners.</p>
        <div style={{marginTop:20}}>
          <Link href='/menu'><button style={{padding:'12px 22px', background:'#047857', color:'#fff', borderRadius:12}}>Lihat Menu</button></Link>
          <Link href='/franchise'><button style={{padding:'12px 22px', marginLeft:12, borderRadius:12, border:'2px solid #047857'}}>Gabung Franchise</button></Link>
        </div>
      </section>

      <section style={{padding:40, maxWidth:1100, margin:'0 auto'}}>
        <h2 style={{color:'#065f46'}}>Best Seller</h2>
        <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:20, marginTop:16}}>
          {menuData.slice(0,6).map(item=>(
            <div key={item.id} style={{background:'#fff', borderRadius:12, padding:12, boxShadow:'0 6px 18px rgba(0,0,0,0.06)'}}>
              <div style={{width:'100%', height:140, position:'relative', borderRadius:8, overflow:'hidden', background:'#f8fafc'}}>
                <Image src={item.img} alt={item.name} fill style={{objectFit:'cover'}} />
              </div>
              <h3 style={{marginTop:10}}>{item.name}</h3>
              <p style={{color:'#475569'}}>Rp {item.price.toLocaleString()}</p>
            </div>
          ))}
        </div>
      </section>

      <footer style={{padding:24, textAlign:'center', borderTop:'1px solid #e6e6e6', marginTop:40}}>
        © 2025 Nusantara Kelapa. All rights reserved.
      </footer>
    </main>
  )
}
