'use client';
export default function FranchisePage(){
  return (
    <main style={{padding:40, maxWidth:900, margin:'0 auto'}}>
      <h1 style={{color:'#064e3b'}}>Buka Franchise Nusantara Kelapa</h1>
      <p style={{color:'#475569'}}>Paket franchise lengkap: training, SOP, dukungan marketing, supply bahan baku, & support operasional. Investasi mulai Rp 155 juta.</p>
      <ul style={{marginTop:12}}>
        <li>• Franchise fee: Rp 35 juta</li>
        <li>• Modal awal estimasi: Rp 155–180 juta</li>
        <li>• Royalti: 3–5% / atau flat Rp 2 juta/bln</li>
        <li>• ROI: 8–14 bulan</li>
      </ul>
      <a href='https://wa.me/6281234567890?text=Halo%20saya%20ingin%20gabung%20franchise' style={{display:'inline-block', marginTop:16, background:'#047857', color:'#fff', padding:'10px 14px', borderRadius:10}}>Konsultasi via WhatsApp</a>
    </main>
  )
}
