export default function Contact(){
  return (
    <main style={{padding:40, maxWidth:700, margin:'0 auto'}}>
      <h1 style={{color:'#064e3b'}}>Kontak</h1>
      <p>Hubungi kami untuk pemesanan & franchise</p>
      <p>WA: 0812-3456-7890</p>
      <p>Email: nusantarakelapa@gmail.com</p>
    </main>
  )
}
