import Image from 'next/image';
export default function GalleryPage(){
  return (
    <main style={{padding:40}}>
      <h1 style={{color:'#064e3b'}}>Galeri Produk</h1>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))', gap:12, marginTop:12}}>
        {['/images/kelapa1.jpg','/images/kelapa2.jpg','/images/kelapa3.jpg','/images/kelapa4.jpg'].map((src,i)=> (
          <div key={i} style={{position:'relative', height:160, borderRadius:10, overflow:'hidden'}}>
            <Image src={src} alt={'gallery'+i} fill style={{objectFit:'cover'}} />
          </div>
        ))}
      </div>
    </main>
  )
}
