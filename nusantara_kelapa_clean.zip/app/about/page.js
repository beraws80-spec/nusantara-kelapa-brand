export default function AboutPage(){
  return (
    <main style={{padding:40, maxWidth:900, margin:'0 auto'}}>
      <h1 style={{color:'#064e3b'}}>Tentang Nusantara Kelapa</h1>
      <p style={{color:'#475569'}}>Nusantara Kelapa berdiri 10 tahun lalu. Misi kami: menghadirkan minuman kelapa sehat, natural, dan premium sambil mendukung petani lokal.</p>
    </main>
  )
}
