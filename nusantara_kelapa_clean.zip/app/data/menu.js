const menu = [
  { id:1, name: 'Kelapa Original', desc: 'Kelapa muda asli', price: 15000, img: '/images/kelapa1.jpg' },
  { id:2, name: 'Kelapa Susu', desc: 'Kelapa + susu', price: 18000, img: '/images/kelapa2.jpg' },
  { id:3, name: 'Kelapa Lemon', desc: 'Kelapa + lemon', price: 16000, img: '/images/kelapa3.jpg' },
  { id:4, name: 'Kelapa Pandan', desc: 'Kelapa + pandan', price: 17000, img: '/images/kelapa4.jpg' },
  { id:5, name: 'Kelapa Kurma', desc: 'Kelapa + kurma', price: 20000, img: '/images/kelapa5.jpg' },
  { id:6, name: 'Kelapa Gula Aren', desc: 'Kelapa + gula aren', price: 17000, img: '/images/kelapa6.jpg' },
  // ... extend to 28 items as needed
];
export default menu;
