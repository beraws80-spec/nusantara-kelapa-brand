export default function Branches(){
  return (
    <main style={{padding:40, maxWidth:800, margin:'0 auto'}}>
      <h1 style={{color:'#064e3b'}}>Cabang Kami</h1>
      <p>• Sentul (Outlet model) - Omzet Rp 1,3 M/tahun</p>
      <p>• Cabang 2</p>
      <p>• Cabang 3</p>
      <p style={{marginTop:12}}>Target ekspansi: 10 cabang baru tahun 2026.</p>
    </main>
  )
}
