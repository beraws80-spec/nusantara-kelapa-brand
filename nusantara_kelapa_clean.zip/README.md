# Nusantara Kelapa - Full Brand Website (Next.js)

Ini scaffold website brand lengkap untuk **NUSANTARA KELAPA** — siap upload ke Vercel.

## Fitur yang disertakan
- Next.js (app router)
- Halaman: Home, Menu (28 items placeholder), Franchise, About, Gallery, Branches, Contact
- Animasi framer-motion
- Placeholder images di /public/images
- Link download Pitch Deck & Business Plan (letakkan file di /public/files)
- Panduan deploy ke Vercel

## Cara deploy (super gampang)
1. Extract zip ke komputer Anda.
2. (Opsional) Edit file `app/data/menu.js` untuk mengganti menu & harga.
3. Tambahkan foto asli di `public/images/` dan dokumen di `public/files/`.
4. Buka terminal di folder project, jalankan:
   ```
   npm install
   npm run dev
   ```
   lalu buka http://localhost:3000 untuk cek.
5. Di Vercel: Login -> New Project -> Import Git (atau Upload ZIP) -> Deploy.

Kalau mau, saya bantu upload & konfigurasi domain (saya bisa kirim instruksi langkah demi langkah).
