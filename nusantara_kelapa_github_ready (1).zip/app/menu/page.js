'use client';
import menuData from '../data/menu';
import Image from 'next/image';
export default function MenuPage(){
  return (
    <main style={{padding:40}}>
      <h1 style={{color:'#064e3b'}}>Menu Lengkap</h1>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))', gap:20, marginTop:20}}>
        {menuData.map(item=>(
          <div key={item.id} style={{background:'#fff', padding:12, borderRadius:12, boxShadow:'0 4px 12px rgba(0,0,0,0.05)'}}>
            <div style={{height:140, position:'relative', borderRadius:8, overflow:'hidden', background:'#f8fafc'}}>
              <Image src={item.img} alt={item.name} fill style={{objectFit:'cover'}} />
            </div>
            <h3 style={{marginTop:8}}>{item.name}</h3>
            <p style={{color:'#475569'}}>{item.desc}</p>
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:8}}>
              <strong>Rp {item.price.toLocaleString()}</strong>
              <a href={`https://wa.me/6281234567890?text=Pesan%20${encodeURIComponent(item.name)}`} style={{background:'#047857', color:'#fff', padding:'8px 12px', borderRadius:8}}>Pesan</a>
            </div>
          </div>
        ))}
      </div>
    </main>
  )
}
