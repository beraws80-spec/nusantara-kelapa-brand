export const metadata = {
  title: 'Nusantara Kelapa',
  description: 'Fresh • Tropical • Premium Coconut Beverage'
}

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  )
}
